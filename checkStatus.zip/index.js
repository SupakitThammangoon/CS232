// checkStatus.js

const mysql = require('mysql2/promise');

const dbConfig = {
  host:     process.env.DB_HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
};

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "OPTIONS,GET"
};

exports.handler = async (event) => {
  // Handle CORS preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS
    };
  }

  try {
    const caseId = event.queryStringParameters && event.queryStringParameters.id;
    if (!caseId) {
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: false,
          message: "Missing query parameter 'id'"
        })
      };
    }

    const conn = await mysql.createConnection(dbConfig);
    const [rows] = await conn.execute(
      'SELECT status FROM MissingPersons WHERE case_id = ?',
      [caseId]
    );
    await conn.end();

    if (rows.length === 0) {
      return {
        statusCode: 404,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: false,
          message: "Case not found"
        })
      };
    }

    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify({ status: rows[0].status })
    };
  } catch (err) {
    console.error('Error in checkStatus:', err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        success: false,
        message: 'Internal server error'
      })
    };
  }
};