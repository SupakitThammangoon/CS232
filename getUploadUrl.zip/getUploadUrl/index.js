// getUploadUrl.js

const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const BUCKET_NAME = process.env.BUCKET_NAME;

exports.handler = async (event) => {
  // 1) ตอบ Preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST"
      }
    };
  }

  try {
    // 2) อ่าน filename + contentType จาก request body
    const { filename, contentType } = JSON.parse(event.body);
    if (!filename || !contentType) {
      return {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Methods": "OPTIONS,POST"
        },
        body: JSON.stringify({ success: false, message: "Missing filename or contentType" })
      };
    }

    // 3) สร้าง key และ pre-signed URL
    const key = `missing/${Date.now()}-${filename}`;
    const uploadUrl = await s3.getSignedUrlPromise('putObject', {
      Bucket: BUCKET_NAME,
      Key: key,
      Expires: 60,
      ContentType: contentType
    });

    // 4) URL สาธารณะที่อ่านไฟล์ได้
    const fileUrl = `https://${BUCKET_NAME}.s3.amazonaws.com/${key}`;

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST"
      },
      body: JSON.stringify({ uploadUrl, fileUrl })
    };
  } catch (err) {
    console.error("Error in getUploadUrl:", err);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST"
      },
      body: JSON.stringify({ success: false, message: "Could not generate upload URL." })
    };
  }
};
