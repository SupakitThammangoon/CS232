// getUploadUrl.js

const AWS = require('aws-sdk');
const s3 = new AWS.S3();
const BUCKET_NAME = process.env.BUCKET_NAME; // กำหนดใน Lambda env vars

exports.handler = async (event) => {
  try {
    // อ่าน filename จาก request body
    const { filename } = JSON.parse(event.body);
    if (!filename) {
      return {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Methods": "OPTIONS,POST"
        },
        body: JSON.stringify({ success: false, message: "Missing filename" })
      };
    }

    // สร้าง S3 key
    const key = `missing/${Date.now()}-${filename}`;

    // ขอ pre-signed PUT URL (หมดอายุใน 60 วินาที)
    const uploadUrl = await s3.getSignedUrlPromise('putObject', {
      Bucket: BUCKET_NAME,
      Key: key,
      Expires: 60,
      ContentType: 'image/jpeg' // ปรับตามชนิดไฟล์ที่รองรับ
    });

    // URL ที่เข้าถึงไฟล์ได้หลังอัปโหลด
    const fileUrl = `https://${BUCKET_NAME}.s3.amazonaws.com/${key}`;

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST"
      },
      body: JSON.stringify({ uploadUrl, fileUrl })
    };
  } catch (err) {
    console.error("Error in getUploadUrl:", err);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST"
      },
      body: JSON.stringify({ success: false, message: "Could not generate upload URL." })
    };
  }
};
