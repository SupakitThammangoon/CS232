// searchMissingPerson.js

const mysql = require('mysql2/promise');

const dbConfig = {
  host:     process.env.DB_HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
};

exports.handler = async (event) => {
  // รองรับ preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,GET"
      }
    };
  }

  try {
    const qp = event.queryStringParameters || {};
    const {
      dateFrom, // รูปแบบ YYYY-MM-DD
      dateTo,
      gender,
      ageMin,
      ageMax,
      province,
      full_name
    } = qp;

    let sql = `
      SELECT
        case_id,
        full_name,
        age,
        gender,
        last_seen_date,
        last_seen_location AS province,
        description,
        photo_url
      FROM MissingPersons
      WHERE 1=1
    `;
    const params = [];

    // กรองวันที่โดยใช้ DATE()
    if (dateFrom) {
      sql += ` AND DATE(last_seen_date) >= ?`;
      params.push(dateFrom);
    }
    if (dateTo) {
      sql += ` AND DATE(last_seen_date) <= ?`;
      params.push(dateTo);
    }

    if (gender) {
      sql += ` AND gender = ?`;
      params.push(gender);
    }
    if (ageMin) {
      sql += ` AND age >= ?`;
      params.push(parseInt(ageMin, 10));
    }
    if (ageMax) {
      sql += ` AND age <= ?`;
      params.push(parseInt(ageMax, 10));
    }
    if (province) {
      sql += ` AND last_seen_location = ?`;
      params.push(province);
    }
    if (full_name) {
      sql += ` AND full_name LIKE ?`;
      params.push(`%${full_name}%`);
    }
    

    sql += ` ORDER BY last_seen_date DESC`;

    const conn = await mysql.createConnection(dbConfig);
    const [rows] = await conn.execute(sql, params);
    await conn.end();

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,GET"
      },
      body: JSON.stringify(rows)
    };

  } catch (err) {
    console.error('Error in searchCases:', err);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,GET"
      },
      body: JSON.stringify({ success: false, message: 'Internal server error.' })
    };
  }
};
