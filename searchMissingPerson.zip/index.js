// searchCases.js
const mysql = require('mysql2/promise');
const dbConfig = {
    host:     process.env.DB_HOST,
    user:     process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME
  };

exports.handler = async (event) => {
  // อ่าน query params
  const q = event.queryStringParameters || {};
  const dateFrom = q.date_from || null;
  const dateTo   = q.date_to   || null;
  const gender   = q.gender    || null;
  const ageMin   = q.age_min   ? Number(q.age_min) : null;
  const ageMax   = q.age_max   ? Number(q.age_max) : null;
  const province = q.province  || null;

  // สร้าง SQL WHERE clauses
  let sql = `SELECT case_id, full_name, age, gender, last_seen_date, last_seen_location AS province, photo_url
             FROM MissingPersons
             WHERE 1=1`;
  const params = [];
  if (dateFrom) {
    sql += ` AND last_seen_date >= ?`;
    params.push(dateFrom);
  }
  if (dateTo) {
    sql += ` AND last_seen_date <= ?`;
    params.push(dateTo);
  }
  if (gender) {
    sql += ` AND gender = ?`;
    params.push(gender);
  }
  if (ageMin !== null) {
    sql += ` AND age >= ?`;
    params.push(ageMin);
  }
  if (ageMax !== null) {
    sql += ` AND age <= ?`;
    params.push(ageMax);
  }
  if (province) {
    sql += ` AND last_seen_location = ?`;
    params.push(province);
  }

  const conn = await mysql.createConnection(dbConfig);
  const [rows] = await conn.execute(sql, params);
  await conn.end();

  return {
    statusCode: 200,
    headers: {
      "Access-Control-Allow-Origin":"*",
      "Access-Control-Allow-Headers":"Content-Type",
      "Access-Control-Allow-Methods":"GET,OPTIONS"
    },
    body: JSON.stringify(rows)
  };
};
