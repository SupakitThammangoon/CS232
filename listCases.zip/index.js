// listCases.js

const mysql = require('mysql2/promise');

// DB config from environment variables
const dbConfig = {
  host:     process.env.DB_HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
};

exports.handler = async (event) => {
  // รองรับ preflight request
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,GET"
      }
    };
  }

  try {
    const conn = await mysql.createConnection(dbConfig);

    // Query เคสทั้งหมด เรียงวันที่หายล่าสุดก่อน
    const [rows] = await conn.execute(
      `SELECT
         case_id,
         full_name,
         age,
         gender,
         last_seen_date,
         last_seen_location,
         photo_url
       FROM MissingPersons
       ORDER BY last_seen_date DESC`
    );
    await conn.end();

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,GET"
      },
      body: JSON.stringify(rows)
    };
  } catch (err) {
    console.error('Error in listCases:', err);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,GET"
      },
      body: JSON.stringify({ success: false, message: 'Could not load cases.' })
    };
  }
};
