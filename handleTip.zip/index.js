const AWS = require('aws-sdk');
const mysql = require('mysql2/promise');
const { v4: uuidv4 } = require('uuid');

// AWS Resources
const s3 = new AWS.S3();

// Environment Configs
const dbConfig = {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
};
const BUCKET_NAME = 'missing-persons-photos';

exports.handler = async (event) => {
  try {
    const body = JSON.parse(event.body);
    const {
      case_id,
      tipper_name,
      tipper_contact,
      tip_location,
      tip_description,
      photo_base64
    } = body;

    const tip_id = uuidv4();
    let photo_url = null;

    // Upload photo to S3 if provided
    if (photo_base64) {
      const photoBuffer = Buffer.from(photo_base64.replace(/^data:image\/\w+;base64,/, ''), 'base64');
      const photoKey = `tips/${tip_id}.jpg`;

      await s3.putObject({
        Bucket: BUCKET_NAME,
        Key: photoKey,
        Body: photoBuffer,
        ContentType: 'image/jpeg'
      }).promise();

      photo_url = `https://${BUCKET_NAME}.s3.amazonaws.com/${photoKey}`;
    }

    // Save tip to MySQL
    const connection = await mysql.createConnection(dbConfig);
    await connection.execute(
      `INSERT INTO Tips 
        (tip_id, case_id, tipper_name, tipper_contact, tip_location, tip_description, photo_url) 
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [tip_id, case_id, tipper_name, tipper_contact, tip_location, tip_description, photo_url]
    );
    await connection.end();

    // ✅ Response with CORS headers
    return {
      statusCode: 200,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST'
      },
      body: JSON.stringify({ success: true, tip_id })
    };

  } catch (error) {
    console.error('Tip submission error:', error);

    return {
      statusCode: 500,
      headers: {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST'
      },
      body: JSON.stringify({ success: false, message: 'Failed to submit tip.' })
    };
  }
};
