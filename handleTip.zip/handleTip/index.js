// handleTips.js

const AWS = require('aws-sdk');
const mysql = require('mysql2/promise');
const { v4: uuidv4 } = require('uuid');

const s3 = new AWS.S3();
const dbConfig = {
  host:     process.env.DB_HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
};
const BUCKET_NAME = 'missing-persons-photo';

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "OPTIONS,POST,GET"
};

exports.handler = async (event) => {
  // ตอบ preflight OPTIONS
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS
    };
  }

  try {
    const body = JSON.parse(event.body);
    const {
      case_id,
      tipper_name,
      tipper_contact,
      tip_location,
      tip_description,
      photo_base64
    } = body;

    const tip_id = uuidv4();
    let photo_url = null;

    if (photo_base64) {
      const photoBuffer = Buffer.from(
        photo_base64.replace(/^data:image\/\w+;base64,/, ''),
        'base64'
      );
      const photoKey = `tips/${tip_id}.jpg`;
      await s3.putObject({
        Bucket: BUCKET_NAME,
        Key: photoKey,
        Body: photoBuffer,
        ContentType: 'image/jpeg'
      }).promise();
      photo_url = `https://${BUCKET_NAME}.s3.amazonaws.com/${photoKey}`;
    }

    const connection = await mysql.createConnection(dbConfig);
    await connection.execute(
      `INSERT INTO Tips
       (tip_id, case_id, tipper_name, tipper_contact, tip_location, tip_description, photo_url)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [tip_id, case_id, tipper_name, tipper_contact, tip_location, tip_description, photo_url]
    );
    await connection.end();

    return {
      statusCode: 200,
      headers: CORS_HEADERS,            // เพิ่ม CORS headers
      body: JSON.stringify({ success: true, tip_id })
    };

  } catch (err) {
    console.error('Error in handleTips:', err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,            // เพิ่ม CORS headers
      body: JSON.stringify({ success: false, message: 'Failed to submit tip.' })
    };
  }
};
