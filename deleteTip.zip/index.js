// deleteTip.js

const mysql = require('mysql2/promise');

const dbConfig = {
  host:     process.env.DB_HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
};

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "OPTIONS,DELETE"
};

exports.handler = async (event) => {
  // ตอบ preflight
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: CORS };
  }

  // ดึง tip_id จาก path parameter
  const tipId = event.pathParameters && event.pathParameters.tip_id;
  if (!tipId) {
    return {
      statusCode: 400,
      headers: CORS,
      body: JSON.stringify({ success: false, message: "Missing tip_id" })
    };
  }

  try {
    const conn = await mysql.createConnection(dbConfig);
    const [result] = await conn.execute(
      'DELETE FROM Tips WHERE tip_id = ?',
      [tipId]
    );
    await conn.end();

    if (result.affectedRows === 0) {
      return {
        statusCode: 404,
        headers: CORS,
        body: JSON.stringify({ success: false, message: "Tip not found" })
      };
    }

    return {
      statusCode: 200,
      headers: CORS,
      body: JSON.stringify({ success: true, tip_id: tipId })
    };

  } catch (err) {
    console.error("Error deleting tip:", err);
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ success: false, message: "Internal server error" })
    };
  }
};
