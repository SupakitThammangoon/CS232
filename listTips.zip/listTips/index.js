// listTips.js
const mysql = require('mysql2/promise');

const dbConfig = {
  host:     process.env.DB_HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
};

const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "OPTIONS,GET"
};

exports.handler = async (event) => {
  if (event.httpMethod === 'OPTIONS') {
    return { statusCode: 200, headers: CORS };
  }

  const caseId = event.queryStringParameters?.case_id;
  if (!caseId) {
    return {
      statusCode: 400,
      headers: CORS,
      body: JSON.stringify({ success: false, message: "Missing case_id" })
    };
  }

  try {
    const conn = await mysql.createConnection(dbConfig);

    // JOIN Tips กับ MissingPersons เพื่อดึงรูปเคส
    const [rows] = await conn.execute(
      `SELECT 
         t.tip_id,
         t.case_id,
         t.tipper_name,
         t.tipper_contact,
         t.tip_location,
         t.tip_description,
         mp.photo_url AS case_photo_url,
         t.created_at
       FROM Tips t
       LEFT JOIN MissingPersons mp 
         ON t.case_id = mp.case_id
       WHERE t.case_id = ?
       ORDER BY t.created_at DESC`,
      [caseId]
    );
    await conn.end();

    return {
      statusCode: 200,
      headers: CORS,
      body: JSON.stringify(rows)
    };
  } catch (err) {
    console.error("Error in listTips:", err);
    return {
      statusCode: 500,
      headers: CORS,
      body: JSON.stringify({ success: false, message: "Internal server error" })
    };
  }
};
