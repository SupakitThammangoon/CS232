// listTips.js

const mysql = require('mysql2/promise');

const dbConfig = {
  host:     process.env.DB_HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
};

const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Content-Type",
  "Access-Control-Allow-Methods": "OPTIONS,GET"
};

exports.handler = async (event) => {
  // ตอบ preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: CORS_HEADERS
    };
  }

  try {
    // อ่าน case_id จาก querystring
    const caseId = event.queryStringParameters && event.queryStringParameters.case_id;
    if (!caseId) {
      return {
        statusCode: 400,
        headers: CORS_HEADERS,
        body: JSON.stringify({
          success: false,
          message: "Missing query parameter 'case_id'"
        })
      };
    }

    // เชื่อมฐานข้อมูล
    const conn = await mysql.createConnection(dbConfig);

    // ดึงเบาะแสทั้งหมดของเคสนั้น
    const [rows] = await conn.execute(
      `SELECT 
         tip_id,
         case_id,
         tipper_name,
         tipper_contact,
         tip_location,
         tip_description,
         photo_url,
         created_at
       FROM Tips
       WHERE case_id = ?
       ORDER BY created_at DESC`,
      [caseId]
    );
    await conn.end();

    // ส่งกลับ array ของ rows
    return {
      statusCode: 200,
      headers: CORS_HEADERS,
      body: JSON.stringify(rows)
    };

  } catch (err) {
    console.error("Error in listTips:", err);
    return {
      statusCode: 500,
      headers: CORS_HEADERS,
      body: JSON.stringify({
        success: false,
        message: "Internal server error"
      })
    };
  }
};
