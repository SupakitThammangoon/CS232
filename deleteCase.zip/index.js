// deleteCase.js

const mysql = require('mysql2/promise');
const dbConfig = {
  host:     process.env.DB_HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
};

exports.handler = async (event) => {
  // ถ้าเป็น preflight
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,DELETE"
      }
    };
  }

  const caseId = event.pathParameters && event.pathParameters.id;
  if (!caseId) {
    return {
      statusCode: 400,
      headers: { "Access-Control-Allow-Origin": "*" },
      body: JSON.stringify({ success: false, message: "Missing case_id" })
    };
  }

  try {
    const conn = await mysql.createConnection(dbConfig);

    const [result] = await conn.execute(
      'DELETE FROM MissingPersons WHERE case_id = ?', 
      [caseId]
    );
    await conn.end();

    if (result.affectedRows === 0) {
      // ไม่มีแถวถูกลบ
      return {
        statusCode: 404,
        headers: { "Access-Control-Allow-Origin": "*" },
        body: JSON.stringify({ success: false, message: "Case not found" })
      };
    }

    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,DELETE"
      },
      body: JSON.stringify({ success: true, case_id: caseId })
    };
  } catch (err) {
    console.error("Error deleting case:", err);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,DELETE"
      },
      body: JSON.stringify({ success: false, message: "Internal server error." })
    };
  }
};
