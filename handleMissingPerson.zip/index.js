// reportCase.js
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const dbConfig = {
  host: process.env.DB_HOST,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
};
const sns = new AWS.SNS();
const SNS_TOPIC_ARN = process.env.SNS_TOPIC_ARN;

exports.handler = async (event) => {
  try {
    const {
      reporter_id,
      full_name,
      age,
      gender,
      last_seen_date,
      last_seen_location,
      description,
      photo_url
    } = JSON.parse(event.body);

    const case_id = uuidv4();

    // เขียนลงฐานข้อมูล
    const conn = await mysql.createConnection(dbConfig);
    await conn.execute(
      `INSERT INTO MissingPersons
       (case_id, reporter_id, full_name, age, gender, last_seen_date, last_seen_location, description, photo_url)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [case_id, reporter_id, full_name, age, gender, last_seen_date, last_seen_location, description, photo_url]
    );

    // ดึงอีเมล reporter
    const [rows] = await conn.execute(
      `SELECT email FROM Users WHERE user_id = ?`, [reporter_id]
    );
    await conn.end();

    // ส่ง SNS ไปแจ้งทางอีเมล
    if (rows.length) {
      await sns.publish({
        TopicArn: SNS_TOPIC_ARN,
        Subject: 'Missing Person Case Registered',
        Message: `Your case (${case_id}) has been registered successfully.`,
        MessageAttributes: {
          email: {
            DataType: 'String',
            StringValue: rows[0].email
          }
        }
      }).promise();
    }

    return {
      statusCode: 200,
      headers: { 'Content-Type': 'application/json','Access-Control-Allow-Origin':'*' },
      body: JSON.stringify({ success: true, case_id })
    };

  } catch (err) {
    console.error(err);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json','Access-Control-Allow-Origin':'*' },
      body: JSON.stringify({ success: false, message: 'Internal server error.' })
    };
  }
};
