// handleMissingPerson.js
const mysql = require('mysql2/promise');
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');

const dbConfig = {
  host:     process.env.DB_HOST,
  user:     process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME
};
const sns = new AWS.SNS();
const SNS_TOPIC_ARN = process.env.SNS_TOPIC_ARN;

exports.handler = async (event) => {
  try {
    const body = JSON.parse(event.body);

    // map ค่าจาก request
    const full_name           = body.full_name           ?? null;
    const age                 = (body.age !== undefined) ? Number(body.age) : null;
    const gender              = body.gender              ?? null;
    const last_seen_date      = body.last_seen_date      ?? null;
    const last_seen_location  = body.last_seen_location  ?? null;
    const description         = body.description         ?? null;
    const photo_url           = body.photo_url           ?? null;

    // ตรวจค่าบังคับ
    if (!full_name || !last_seen_date) {
      return {
        statusCode: 400,
        headers: {
          "Access-Control-Allow-Origin": "*",
          "Access-Control-Allow-Headers": "Content-Type",
          "Access-Control-Allow-Methods": "OPTIONS,POST"
        },
        body: JSON.stringify({
          success: false,
          message: "Missing required fields: full_name or last_seen_date"
        })
      };
    }

    const case_id = uuidv4();
    const conn = await mysql.createConnection(dbConfig);

    // INSERT โดยไม่ใส่ reporter_id
    await conn.execute(
      `INSERT INTO MissingPersons
       (case_id, full_name, age, gender, last_seen_date, last_seen_location, description, photo_url)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        case_id,
        full_name,
        age,
        gender,
        last_seen_date,
        last_seen_location,
        description,
        photo_url
      ]
    );

    await conn.end();

    // (คุณอาจข้าม SNS ถ้าไม่เก็บ reporter_id)
    // return success
    return {
      statusCode: 200,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST"
      },
      body: JSON.stringify({ success: true, case_id })
    };

  } catch (err) {
    console.error('Error in reportCase:', err);
    return {
      statusCode: 500,
      headers: {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type",
        "Access-Control-Allow-Methods": "OPTIONS,POST"
      },
      body: JSON.stringify({ success: false, message: 'Internal server error.' })
    };
  }
};
